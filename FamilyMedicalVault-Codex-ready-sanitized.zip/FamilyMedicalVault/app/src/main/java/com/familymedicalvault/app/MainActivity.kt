package com.familymedicalvault.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.familymedicalvault.app.data.VaultPreferences
import com.familymedicalvault.app.data.VaultStorage
import com.familymedicalvault.app.model.MedicalCategory
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MedicalVaultApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MedicalVaultApp() {
    val context = LocalContext.current
    val prefs = remember { VaultPreferences(context) }
    val storage = remember { VaultStorage(context) }
    val scope = rememberCoroutineScope()
    val rootUriString by prefs.rootUri.collectAsStateWithLifecycle(initialValue = null)
    val rootUri = rootUriString?.let(Uri::parse)

    var selectedPerson by remember { mutableStateOf<String?>(null) }
    var selectedCategory by remember { mutableStateOf(MedicalCategory.EXAMS) }
    var newPersonName by remember { mutableStateOf("") }
    var refreshTick by remember { mutableIntStateOf(0) }

    val treePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            runCatching { context.contentResolver.takePersistableUriPermission(uri, flags) }
            scope.launch { prefs.saveRootUri(uri.toString()) }
        }
    }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val person = selectedPerson
        val root = rootUri
        if (uri != null && person != null && root != null) {
            storage.importDocument(root, person, selectedCategory, uri)
            refreshTick++
        }
    }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("Ιατρικός Φάκελος") }) }
        ) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (rootUri == null) {
                    Text("Διάλεξε έναν φάκελο που θα χρησιμοποιείται αποκλειστικά ως οικογενειακό ιατρικό αρχείο.")
                    Button(onClick = { treePicker.launch(null) }) {
                        Text("Σύνδεση φακέλου")
                    }
                    Text("Η εφαρμογή δεν ζητά γενική πρόσβαση στα αρχεία και δεν χρησιμοποιεί Internet.")
                    return@Column
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = newPersonName,
                        onValueChange = { newPersonName = it },
                        label = { Text("Νέο πρόσωπο") },
                        modifier = Modifier.weight(1f)
                    )
                    Button(onClick = {
                        if (newPersonName.isNotBlank()) {
                            storage.createPerson(rootUri, newPersonName)
                            newPersonName = ""
                            refreshTick++
                        }
                    }) { Text("Προσθήκη") }
                }

                val people = remember(rootUriString, refreshTick) { storage.listPeople(rootUri) }
                if (selectedPerson == null) {
                    Text("Πρόσωπα", style = MaterialTheme.typography.titleMedium)
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(people, key = { it.uri.toString() }) { person ->
                            ElevatedCard(
                                modifier = Modifier.fillMaxWidth().clickable { selectedPerson = person.name }
                            ) {
                                Column(Modifier.padding(16.dp)) {
                                    Text(person.name ?: "Χωρίς όνομα", style = MaterialTheme.typography.titleMedium)
                                    Text("Άνοιγμα ιατρικού φακέλου")
                                }
                            }
                        }
                    }
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { selectedPerson = null }) { Text("← Πρόσωπα") }
                        Spacer(Modifier.width(8.dp))
                        Text(selectedPerson!!, style = MaterialTheme.typography.titleLarge)
                    }

                    CategoryChooser(selectedCategory) { selectedCategory = it }

                    Button(onClick = { filePicker.launch(arrayOf("application/pdf", "image/*", "text/plain")) }) {
                        Text("Προσθήκη αρχείου στην κατηγορία ${selectedCategory.folderName}")
                    }

                    val docs = remember(selectedPerson, selectedCategory, refreshTick) {
                        storage.listDocuments(rootUri, selectedPerson!!, selectedCategory)
                    }
                    if (docs.isEmpty()) {
                        Text("Δεν υπάρχουν αρχεία σε αυτή την κατηγορία.")
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(docs, key = { it.uri.toString() }) { doc ->
                                DocumentRow(doc)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CategoryChooser(current: MedicalCategory, onSelected: (MedicalCategory) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        MedicalCategory.entries.chunked(3).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                row.forEach { category ->
                    FilterChip(
                        selected = current == category,
                        onClick = { onSelected(category) },
                        label = { Text(category.folderName) }
                    )
                }
            }
        }
    }
}

@Composable
private fun DocumentRow(doc: DocumentFile) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text(doc.name ?: "Αρχείο", style = MaterialTheme.typography.bodyLarge)
            Text(doc.type ?: "Άγνωστος τύπος", style = MaterialTheme.typography.bodySmall)
        }
    }
}
