# FamilyMedicalVault — Codex instructions

## Scope
Work only in this repository. This is a private Android app and is completely separate from the public app "Η Υγεία μου". Never modify or reference any unrelated repository.

## Product goal
Build a private, local-first family medical document vault for Android. The user explicitly selects one vault root folder through Android's Storage Access Framework. The app organizes documents per family member and category and accepts PDFs/images from Android Share.

## Security invariants
- DO NOT add `MANAGE_EXTERNAL_STORAGE`.
- DO NOT add broad legacy storage permissions.
- DO NOT add `INTERNET` permission in this phase.
- Keep `ACTION_OPEN_DOCUMENT_TREE` / persisted URI permission as the only shared-storage access mechanism.
- Never silently delete or overwrite a document.
- Do not upload health data anywhere.
- Treat all stored content as sensitive health information.

## Required first milestone
1. Make the project compile cleanly with current stable Android/Gradle tooling.
2. Add/repair a Gradle wrapper if needed.
3. Run unit tests and `assembleDebug`.
4. Fix every compile/build error.
5. Produce `app-debug.apk` and report its path.
6. Do not redesign the app unless needed for correctness/usability.

## Required functional checks
- User can select a vault root with system folder picker and the URI permission persists after restart.
- User can create/select a family member.
- Standard categories exist: Εξετάσεις, Απεικονίσεις, Εμβόλια, Φάρμακα, Νοσηλείες, Γνωματεύσεις.
- User can import PDF/image into the chosen member/category.
- Incoming Android Share for PDF/images opens the app and lets the user choose member/category before copying.
- Naming conflicts never overwrite an existing document.

## Phase 2 after the first successful APK
Implement incrementally with tests:
- biometric/device-credential app lock;
- metadata model: person, category, exam_date, provider, document_type, notes, original_filename, sha256;
- SHA-256 duplicate detection;
- safe rename/move with confirmation;
- per-person JSON index export;
- tests for filename sanitation, directory creation, duplicate handling, metadata serialization.

Do not start any remote connector/MCP/internet feature until the local APK milestone and security review are complete.
