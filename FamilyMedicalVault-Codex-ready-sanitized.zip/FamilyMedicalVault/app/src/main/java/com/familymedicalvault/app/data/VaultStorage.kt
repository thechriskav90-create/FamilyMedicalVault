package com.familymedicalvault.app.data

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.familymedicalvault.app.model.MedicalCategory
import java.util.UUID

class VaultStorage(private val context: Context) {

    fun root(uri: Uri): DocumentFile? = DocumentFile.fromTreeUri(context, uri)

    fun listPeople(rootUri: Uri): List<DocumentFile> =
        root(rootUri)?.listFiles()?.filter { it.isDirectory }?.sortedBy { it.name } ?: emptyList()

    fun createPerson(rootUri: Uri, displayName: String): DocumentFile? {
        val root = root(rootUri) ?: return null
        val safeName = sanitize(displayName)
        val existing = root.findFile(safeName)
        val person = existing ?: root.createDirectory(safeName) ?: return null
        MedicalCategory.entries.forEach { category ->
            if (person.findFile(category.folderName) == null) {
                person.createDirectory(category.folderName)
            }
        }
        return person
    }

    fun categoryDirectory(rootUri: Uri, personFolder: String, category: MedicalCategory): DocumentFile? {
        val person = root(rootUri)?.findFile(personFolder) ?: return null
        return person.findFile(category.folderName) ?: person.createDirectory(category.folderName)
    }

    fun importDocument(
        rootUri: Uri,
        personFolder: String,
        category: MedicalCategory,
        sourceUri: Uri,
        preferredName: String? = null
    ): Result<String> = runCatching {
        val targetDir = categoryDirectory(rootUri, personFolder, category)
            ?: error("Δεν βρέθηκε ο φάκελος προορισμού")

        val source = DocumentFile.fromSingleUri(context, sourceUri)
        val sourceName = preferredName?.takeIf { it.isNotBlank() }
            ?: source?.name
            ?: "αρχείο-${UUID.randomUUID()}"
        val mime = context.contentResolver.getType(sourceUri) ?: "application/octet-stream"
        val safeName = uniqueName(targetDir, sanitizeFileName(sourceName))
        val target = targetDir.createFile(mime, safeName) ?: error("Αποτυχία δημιουργίας αρχείου")

        context.contentResolver.openInputStream(sourceUri).use { input ->
            requireNotNull(input) { "Αδυναμία ανάγνωσης αρχείου" }
            context.contentResolver.openOutputStream(target.uri, "w").use { output ->
                requireNotNull(output) { "Αδυναμία εγγραφής αρχείου" }
                input.copyTo(output)
            }
        }
        target.uri.toString()
    }

    fun listDocuments(rootUri: Uri, personFolder: String, category: MedicalCategory): List<DocumentFile> =
        categoryDirectory(rootUri, personFolder, category)?.listFiles()?.sortedByDescending { it.lastModified() } ?: emptyList()

    private fun uniqueName(dir: DocumentFile, name: String): String {
        if (dir.findFile(name) == null) return name
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 2
        while (dir.findFile("$base ($i)$ext") != null) i++
        return "$base ($i)$ext"
    }

    private fun sanitize(value: String): String =
        value.trim().replace(Regex("[\\/:*?\"<>|]"), "-").ifBlank { "Πρόσωπο" }

    private fun sanitizeFileName(value: String): String =
        value.trim().replace(Regex("[\\/:*?\"<>|]"), "-").ifBlank { "αρχείο" }
}
