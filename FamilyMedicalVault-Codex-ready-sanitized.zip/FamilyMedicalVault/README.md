# Family Medical Vault / Ιατρικός Φάκελος

Ιδιωτικό Android companion app για οικογενειακό ιατρικό αρχείο. Είναι ανεξάρτητο από την εφαρμογή «Η Υγεία μου».

## MVP 0.1

- Επιλογή ενός root φακέλου με Android Storage Access Framework (`ACTION_OPEN_DOCUMENT_TREE`).
- Μόνιμη άδεια στον συγκεκριμένο φάκελο μέσω persistable URI permission.
- Χωρίς `MANAGE_EXTERNAL_STORAGE`, χωρίς γενική πρόσβαση στο filesystem.
- Χωρίς `INTERNET` permission.
- Δημιουργία ξεχωριστού φακέλου ανά άτομο.
- Αυτόματες κατηγορίες:
  - Εξετάσεις
  - Απεικονίσεις
  - Εμβόλια
  - Φάρμακα
  - Νοσηλείες
  - Γνωματεύσεις
- Εισαγωγή PDF/εικόνας/κειμένου στον σωστό φάκελο.
- Αυτόματη αποφυγή overwrite με `(2)`, `(3)` κ.λπ.

## Privacy model

Η εφαρμογή δεν διαβάζει τίποτα πριν ο χρήστης επιλέξει φάκελο από τον επίσημο Android picker. Η πρόσβαση περιορίζεται στο επιλεγμένο directory tree.

## Τι ΔΕΝ υπάρχει ακόμα

- Cloud sync
- ChatGPT/MCP connector
- OCR/AI ταξινόμηση
- Αυτόματη αναγνώριση προσώπου από έγγραφο
- Κρυπτογράφηση αρχείων πέρα από την προστασία του Android storage
- Βιομετρικό κλείδωμα

Αυτά είναι σκόπιμα Phase 2 ώστε το πρώτο build να παραμένει local-only και ελεγχόμενο.

## Άνοιγμα

1. Άνοιξε τον φάκελο `FamilyMedicalVault` στο Android Studio.
2. Άφησε το Gradle sync να ολοκληρωθεί.
3. Run σε Android 8+ συσκευή/emulator.
4. Πάτησε «Σύνδεση φακέλου» και επίλεξε έναν φάκελο π.χ. `Documents/Ιατρικά`.

> Σε Android 11+ το Storage Access Framework δεν επιτρέπει επιλογή του root storage ή του root `Download` directory. Φτιάξε έναν υποφάκελο, π.χ. `Documents/Ιατρικά`.

## Προτεινόμενο Phase 2

1. Biometric/PIN lock.
2. Metadata index (ημερομηνία εξέτασης, εργαστήριο, είδος, tags).
3. Share-to-vault Android share target.
4. Duplicate detection με SHA-256.
5. Optional encrypted sync backend.
6. Remote MCP server με read-only default και explicit confirmation για writes.
7. ChatGPT commands όπως:
   - «Βρες την τελευταία CT του πατέρα.»
   - «Αποθήκευσε αυτό το PDF στη μητέρα / 2026 / Εργαστηριακά.»
   - «Δείξε όλες τις εξετάσεις LDL του επιλεγμένου προφίλ.»

## Codex next task

Δες το `CODEX_TASK.md`.

## v0.2 update

The app now registers as an Android share target for PDF, images and plain text. From Android Files/Downloads you can use **Share → Ιατρικός Φάκελος**, then choose the family member and destination category before copying the file into the selected vault folder.

See `BUILD_AND_TEST.md` for build/install steps.
