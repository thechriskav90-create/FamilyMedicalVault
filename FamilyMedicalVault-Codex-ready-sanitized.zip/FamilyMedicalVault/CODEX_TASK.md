# Codex task — Phase 2

Work only in this repository. Do not modify any unrelated project, especially the public "Η Υγεία μου" application.

## Goal
Turn the local-only MVP into a robust private family medical vault while preserving least-privilege Android storage access.

## Requirements
1. Keep Storage Access Framework as the only shared-storage access mechanism.
2. Do not request MANAGE_EXTERNAL_STORAGE.
3. Keep INTERNET permission absent until the remote connector phase is explicitly enabled.
4. Add biometric/PIN app lock.
5. Add metadata model per file:
   - person
   - category
   - exam_date
   - provider
   - document_type
   - notes
   - original_filename
   - SHA-256
6. Add duplicate detection.
7. Add Android share target: Share PDF/image -> Medical Vault -> select person/category.
8. Add safe rename/move actions with confirmation.
9. Add export of an individual person's index as JSON.
10. Add tests for filename sanitation, duplicate handling, directory creation, and metadata serialization.

## Later, separate security review
Design an optional remote connector/MCP bridge. Default read-only. Every write/delete/rename must require explicit user confirmation and must be scoped to the selected vault root.
