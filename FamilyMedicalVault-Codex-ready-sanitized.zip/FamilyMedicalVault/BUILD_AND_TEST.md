# Build & test — Family Medical Vault

## Current milestone (v0.2)

Local-only Android application. It deliberately declares **no INTERNET permission** and no broad storage permission.

Implemented:
- Android Storage Access Framework root-folder selection.
- Persisted access to only the user-selected folder.
- Separate person folders and medical categories.
- PDF/image/text import from the app.
- Android **Share → Ιατρικός Φάκελος** flow with person + category selection.
- Duplicate filename collision handling (`name (2).pdf`, etc.).

## Android Studio build

1. Open the `FamilyMedicalVault` folder in current Android Studio.
2. Allow Gradle sync to finish.
3. If Android Studio asks for SDK 36, install Android SDK Platform 36 and Build Tools 36.x from SDK Manager.
4. Build > Make Project.
5. Build > Build App Bundle(s) / APK(s) > Build APK(s).
6. Debug APK should appear under `app/build/outputs/apk/debug/app-debug.apk`.

Project toolchain:
- Android Gradle Plugin 8.13.0
- Gradle 8.13 minimum
- Kotlin 2.2.20
- compileSdk/targetSdk 36
- minSdk 26

## First phone test

1. Install debug APK on the Android phone.
2. Open `Ιατρικός Φάκελος`.
3. Tap `Σύνδεση φακέλου` and choose/create a dedicated root folder, e.g. `Documents/Ιατρικός Φάκελος`.
4. Add test people.
5. Import one PDF from within the app.
6. From Files/Downloads, Share another PDF or image and select `Ιατρικός Φάκελος`.
7. Pick the person and category and save.
8. Verify the file really exists in the chosen Android folder.

## Security boundary

The app cannot browse outside the tree URI explicitly selected by the user. It does not request MANAGE_EXTERNAL_STORAGE, READ_MEDIA_*, READ_EXTERNAL_STORAGE, WRITE_EXTERNAL_STORAGE, or INTERNET.

## Next milestone

Before any remote ChatGPT bridge:
- Biometric/PIN app lock.
- Metadata sidecar/index (exam date, source, category, owner).
- SHA-256 duplicate detection.
- Safer rename/move/delete confirmation.
- Optional local audit log.

Only after those are stable should a narrowly scoped remote connector/API be considered.
