# Codex run request

Read `AGENTS.md` first and follow it exactly.

Your immediate job is to turn this repository into a verified installable Android debug APK.

1. Inspect the entire project before editing.
2. Validate Gradle/AGP/Kotlin/Compose compatibility and use stable compatible versions if the current combination cannot build.
3. Generate or repair the Gradle wrapper.
4. Run unit tests and `assembleDebug`.
5. Fix all build, manifest, Kotlin, Compose, SAF, share-intent, and resource errors until the build succeeds.
6. Add focused tests where missing for code you touch.
7. Preserve the security invariants in `AGENTS.md` (no INTERNET, no broad storage permissions, no health-data upload).
8. At the end, report exactly:
   - tests run and results;
   - build command used;
   - APK path;
   - any limitations that require a real Android device to verify.

Success criterion: a clean debug build that produces `app/build/outputs/apk/debug/app-debug.apk`.
